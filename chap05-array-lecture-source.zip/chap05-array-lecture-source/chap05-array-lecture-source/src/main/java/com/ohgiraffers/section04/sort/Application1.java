package com.ohgiraffers.section04.sort;

public class Application1 {
    public static void main(String[] args) {

        /* 수업목표. 변수의 두 값을 변경하는 방법에 대해 이해할 수 있다. */
        // 변수의 두 값 변경하기
        int num1 = 10;
        int num2 = 20;

        System.out.println("num1 = " + num1 );
        System.out.println("num2 = " + num2 );

        int temp;       // temp라는 임시 변수 선언
        temp = num1;    // temp에 num1 값 저장 값 : 10
        num1 = num2;    // num1에 num2 값 저장 값 : 20
        num2 = temp;    // num2에 temp 값 저장 값 : 10
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);

        // 배열의 인덱스에 있는 값도 서로 변경할 수 있다.
        int[] arr = {2, 1, 3};

        int temp2;          // temp2라는 임시 변수 선언
        temp2 = arr[0];     // temp2에 arr[0]번 배열 저장 값 : 2
        arr[0] = arr[1];    // arr[0]에 arr[1]번 배열 저장 값 : 1
        arr[1] = temp2;     // arr[1]에 temp2 값 저장 값 : 2

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
